# Tuxcuts 🐧

Apple Shortcuts vibes for Linux. Stack actions into a shortcut, run it from a GUI, the terminal, your app launcher, or a global hotkey. Works on X11 and Wayland (GNOME, KDE, Hyprland, Sway, niri, XFCE…).

## Install

```bash
./install.sh
```

That puts `tuxcut` (CLI) and `tuxcuts` (GUI) in `~/.local/bin`, adds Tuxcuts to your app menu, and drops 7 example shortcuts in `~/.config/tuxcuts/shortcuts/`.

The GUI needs your distro's GTK 3 Python bindings (`python3-gi gir1.2-gtk-3.0` on Debian/Ubuntu, `python-gobject gtk3` on Arch, `python3-gobject gtk3` on Fedora). The installer tells you if they're missing.

Run `tuxcut doctor` to see which helper tools you have. Each feature uses whatever's installed:

| feature | X11 | Wayland |
|---|---|---|
| dialogs | zenity / kdialog / yad | same |
| clipboard | xclip / xsel | wl-clipboard |
| typing + keys | xdotool | wtype (KDE, wlroots) · ydotool (GNOME) |
| screenshots | maim / scrot / spectacle / gnome-screenshot | grim+slurp / spectacle / gnome-screenshot |
| volume · brightness · media | wpctl or pactl · brightnessctl · playerctl | same |

## Use it

```bash
tuxcuts                          # open the editor
tuxcut list
tuxcut run weather
echo "a\nb" | tuxcut run number-lines   # piped text = the shortcut's input
tuxcut new "Morning Setup"       # opens a template in $EDITOR
tuxcut bind quick-note super+shift+n
tuxcut launcher pomodoro         # shows up in your app menu / search
tuxcut actions                   # every action; `tuxcut actions if` for details
```

Hotkeys bind automatically on GNOME and XFCE. On KDE, Hyprland, Sway and niri, `bind` prints the exact line to paste.

## Shortcut files

Plain YAML in `~/.config/tuxcuts/shortcuts/` — the GUI and CLI edit the same files.

```yaml
name: Battery Check
actions:
  - do: read_file
    path: /sys/class/power_supply/BAT0/capacity
    save_as: battery
  - do: if
    condition: is less than
    compare_to: "20"
    then:
      - do: notify
        title: battery at {{battery}}% 🪫
```

- Each step's output becomes `{{result}}` for the next one.
- `save_as: name` on any step keeps its output as `{{name}}`.
- Built-ins: `{{input}}`, `{{date}}`, `{{time}}`, `{{datetime}}`, `{{clipboard}}`, `{{env.HOME}}`.
- Inside loops: `{{repeat_index}}`, and `{{item}}` for Repeat with Each Line.

## Actions (39)

**Text** text, replace_text, change_case, trim, count, split_text, calculate, random_number, get_json_value · **Variables** set_variable, get_variable · **Dialogs** ask_input, choose_from_list, confirm, show_result, notify · **Clipboard** clipboard_get, clipboard_set · **Keyboard** type_text, press_keys · **Web** open_url, http_request · **Files** read_file, save_file, open_file · **Apps** open_app, run_command, screenshot · **System** brightness, lock_screen · **Media** volume, media · **Flow** if, repeat, repeat_each, wait, stop, run_shortcut, comment

Adding your own is one decorated function in `tuxcuts/actions.py` — the GUI builds its form from the `Param` list automatically.
