"""Tuxcuts engine — the action registry, the runner, and shortcut storage.

A shortcut is a YAML file:

    name: Quick Note
    description: jot something down
    icon: accessories-text-editor
    actions:
      - do: ask_input
        prompt: what's on ur mind?
      - do: save_file
        path: ~/Notes/quick.md
        content: "- {{result}}"
        append: true

Each action's output becomes {{result}} for the next one (like Shortcuts'
magic variable). Add `save_as: name` to any step to keep its output as
{{name}} for later.
"""
from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import yaml

from .system import ShortcutError, StopShortcut, clipboard_get

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "tuxcuts"
SHORTCUT_DIR = CONFIG_DIR / "shortcuts"
MAX_DEPTH = 20


# ── action registry ────────────────────────────────────────────────────────

@dataclass
class Param:
    key: str
    label: str
    kind: str = "text"          # text | multiline | number | bool | choice | actions
    default: Any = ""
    choices: list = field(default_factory=list)
    help: str = ""


@dataclass
class ActionSpec:
    name: str
    label: str
    category: str
    icon: str
    help: str
    params: list[Param]
    fn: Callable

    def param(self, key: str) -> Param | None:
        return next((p for p in self.params if p.key == key), None)


ACTIONS: dict[str, ActionSpec] = {}
CATEGORIES = ["Text", "Variables", "Dialogs", "Clipboard", "Keyboard", "Web",
              "Files", "Apps", "System", "Media", "Flow"]


def action(name, label, category, icon="system-run-symbolic", help="", params=()):
    def deco(fn):
        ACTIONS[name] = ActionSpec(name, label, category, icon, help, list(params), fn)
        return fn
    return deco


# ── context + templating ───────────────────────────────────────────────────

@dataclass
class Context:
    input: str = ""
    result: Any = ""
    vars: dict = field(default_factory=dict)
    log: Callable[[str], None] = lambda msg: None
    depth: int = 0


TEMPLATE = re.compile(r"\{\{\s*([\w.\-]+)\s*\}\}")


def render(value: Any, ctx: Context) -> Any:
    if not isinstance(value, str):
        return value

    def sub(m):
        key = m.group(1)
        if key == "result":
            v = ctx.result
        elif key == "input":
            v = ctx.input
        elif key == "date":
            v = time.strftime("%Y-%m-%d")
        elif key == "time":
            v = time.strftime("%H:%M:%S")
        elif key == "datetime":
            v = time.strftime("%Y-%m-%d %H:%M:%S")
        elif key == "clipboard":
            v = clipboard_get()
        elif key.startswith("env."):
            v = os.environ.get(key[4:], "")
        elif key.startswith("vars."):
            v = ctx.vars.get(key[5:], "")
        else:
            v = ctx.vars.get(key, "")
        return "" if v is None else str(v)

    return TEMPLATE.sub(sub, value)


def coerce(p: Param, value: Any) -> Any:
    if p.kind == "number":
        if value in ("", None):
            value = p.default
        try:
            f = float(value)
        except (TypeError, ValueError):
            raise ShortcutError(f"'{p.label}' needs a number, got {value!r}")
        return int(f) if f.is_integer() else f
    if p.kind == "bool":
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "true", "yes", "on", "y")
    if p.kind in ("text", "multiline", "choice"):
        return "" if value is None else str(value)
    return value


# ── runner ─────────────────────────────────────────────────────────────────

def validate(actions: Any, where: str = "actions") -> None:
    if actions is None:
        return
    if not isinstance(actions, list):
        raise ShortcutError(f"{where} should be a list")
    for i, step in enumerate(actions, 1):
        if not isinstance(step, dict) or "do" not in step:
            raise ShortcutError(f"{where} step {i} needs a 'do:' line")
        spec = ACTIONS.get(step["do"])
        if not spec:
            raise ShortcutError(f"{where} step {i}: unknown action '{step['do']}' (try `tuxcut actions`)")
        for p in spec.params:
            if p.kind == "actions":
                validate(step.get(p.key), f"{where} step {i} → {p.key}")


def run_actions(actions: list, ctx: Context) -> Any:
    for step in actions or []:
        spec = ACTIONS.get(step.get("do"))
        if not spec:
            raise ShortcutError(f"unknown action '{step.get('do')}'")
        kwargs = {}
        for p in spec.params:
            raw = step.get(p.key, p.default)
            kwargs[p.key] = raw if p.kind == "actions" else coerce(p, render(raw, ctx))
        ctx.log("  " * ctx.depth + f"→ {spec.label}")
        out = spec.fn(ctx, **kwargs)
        if out is not None:
            ctx.result = out
        if step.get("save_as"):
            ctx.vars[str(step["save_as"])] = ctx.result
    return ctx.result


def run_shortcut(sc: dict, input_text: str = "", log=lambda m: None,
                 parent: Context | None = None) -> Any:
    validate(sc.get("actions"))
    if parent:
        if parent.depth >= MAX_DEPTH:
            raise ShortcutError("shortcuts are calling each other too deep (loop?)")
        ctx = Context(input=input_text, result=input_text, vars=dict(parent.vars),
                      log=parent.log, depth=parent.depth + 1)
    else:
        ctx = Context(input=input_text, result=input_text, log=log)
    try:
        return run_actions(sc.get("actions") or [], ctx)
    except StopShortcut as e:
        ctx.log("  " * ctx.depth + f"■ stopped ({e})" if str(e) else "■ stopped")
        if parent:
            raise
        return ctx.result


# ── storage ────────────────────────────────────────────────────────────────

def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "shortcut"


def load_file(path: Path) -> dict:
    try:
        data = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError as e:
        raise ShortcutError(f"{path.name} isn't valid YAML: {e}")
    if not isinstance(data, dict):
        raise ShortcutError(f"{path.name} should be a mapping with name/actions")
    data.setdefault("name", path.stem)
    data.setdefault("description", "")
    data.setdefault("actions", [])
    data["_path"] = str(path)
    return data


def list_shortcuts() -> list[dict]:
    SHORTCUT_DIR.mkdir(parents=True, exist_ok=True)
    out = []
    for p in sorted(SHORTCUT_DIR.glob("*.y*ml")):
        try:
            out.append(load_file(p))
        except ShortcutError as e:
            out.append({"name": p.stem, "description": f"⚠ {e}", "actions": [], "_path": str(p), "_broken": True})
    return sorted(out, key=lambda s: str(s["name"]).lower())


def find(name: str) -> dict:
    p = Path(name)
    if p.suffix in (".yaml", ".yml") and p.exists():
        return load_file(p)
    want = slugify(name)
    for sc in list_shortcuts():
        if Path(sc["_path"]).stem == want or slugify(str(sc["name"])) == want:
            if sc.get("_broken"):
                raise ShortcutError(sc["description"])
            return sc
    raise ShortcutError(f"no shortcut called '{name}' (see `tuxcut list`)")


def clean(sc: dict) -> dict:
    out = {"name": sc.get("name", "Untitled")}
    if sc.get("description"):
        out["description"] = sc["description"]
    if sc.get("icon"):
        out["icon"] = sc["icon"]
    out["actions"] = sc.get("actions") or []
    return out


def save(sc: dict) -> Path:
    SHORTCUT_DIR.mkdir(parents=True, exist_ok=True)
    validate(sc.get("actions"))
    path = SHORTCUT_DIR / f"{slugify(str(sc['name']))}.yaml"
    old = sc.get("_path")
    if path.exists() and str(path) != old:
        raise ShortcutError(f"a shortcut named '{sc['name']}' already exists")
    path.write_text(yaml.safe_dump(clean(sc), sort_keys=False, allow_unicode=True))
    if old and old != str(path) and Path(old).exists():
        Path(old).unlink()
    sc["_path"] = str(path)
    return path


def delete(sc: dict) -> None:
    if sc.get("_path") and Path(sc["_path"]).exists():
        Path(sc["_path"]).unlink()


# register the built-in actions
from . import actions as _actions  # noqa: E402,F401
