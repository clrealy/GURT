"""Tuxcuts GUI — a block editor for shortcuts (GTK 3)."""
from __future__ import annotations

import copy
import sys
import threading

import yaml

try:
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gdk, Gio, GLib, Gtk, Pango
except (ImportError, ValueError):
    sys.exit("the GUI needs GTK 3 for Python — install python3-gi + gir1.2-gtk-3.0 "
             "(Debian/Ubuntu), python-gobject + gtk3 (Arch), or python3-gobject + gtk3 (Fedora)")

from . import engine, integrations, system
from .engine import ACTIONS, CATEGORIES, Param, ShortcutError

APP_ID = "dev.tuxcuts.Tuxcuts"

CSS = b"""
.tc-card { border-radius: 12px; padding: 10px 12px; margin: 6px 14px;
           background-color: alpha(@theme_fg_color, 0.055);
           border: 1px solid alpha(@theme_fg_color, 0.08); }
.tc-card-title { font-weight: 700; }
.tc-step { font-weight: 700; opacity: 0.45; }
.tc-cat { font-size: 0.85em; font-weight: 700; opacity: 0.55; padding: 8px 10px 2px 10px; }
.tc-empty { opacity: 0.55; padding: 40px; }
.tc-log { font-family: monospace; }
.tc-name { font-size: 1.35em; font-weight: 700; }
"""

SAVE_AS = Param("save_as", "Save result as", help="keep this step's output as {{name}}")


def _multiline(text: str, mono=False, height=64):
    view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, top_margin=4, bottom_margin=4,
                        left_margin=6, right_margin=6, monospace=mono)
    view.get_buffer().set_text(text)
    sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
    sw.set_min_content_height(height)
    sw.set_shadow_type(Gtk.ShadowType.IN)
    sw.add(view)

    def get():
        b = view.get_buffer()
        return b.get_text(b.get_start_iter(), b.get_end_iter(), False)
    return sw, get


def make_field(p: Param, value):
    """Returns (widget, getter) for one action parameter."""
    if p.kind == "bool":
        sw = Gtk.Switch(active=bool(value) if not isinstance(value, str)
                        else value.lower() in ("true", "yes", "1"), halign=Gtk.Align.START)
        return sw, sw.get_active
    if p.kind == "choice":
        combo = Gtk.ComboBoxText()
        for c in p.choices:
            combo.append_text(c)
        if value not in p.choices and value:
            combo.append_text(str(value))
            p_choices = p.choices + [str(value)]
        else:
            p_choices = p.choices
        combo.set_active(p_choices.index(value) if value in p_choices else 0)
        return combo, combo.get_active_text
    if p.kind == "number":
        entry = Gtk.Entry(text=str(value), width_chars=8, halign=Gtk.Align.START,
                          placeholder_text=str(p.default))

        def get_num():
            t = entry.get_text().strip()
            try:
                f = float(t)
                return int(f) if f.is_integer() else f
            except ValueError:
                return t  # keeps {{templates}}
        return entry, get_num
    if p.kind == "actions":
        text = yaml.safe_dump(value or [], sort_keys=False, allow_unicode=True) if value else ""
        sw, get = _multiline(text, mono=True, height=90)

        def get_actions():
            raw = get().strip()
            if not raw:
                return []
            try:
                steps = yaml.safe_load(raw)
            except yaml.YAMLError as e:
                raise ShortcutError(f"'{p.label}' steps aren't valid YAML: {e}")
            engine.validate(steps, p.label)
            return steps
        return sw, get_actions
    if p.kind == "multiline":
        return _multiline(str(value))
    entry = Gtk.Entry(text=str(value), placeholder_text=p.help or "")
    return entry, entry.get_text


class ActionCard(Gtk.Box):
    def __init__(self, win: "Window", step: dict, index: int, total: int):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.get_style_context().add_class("tc-card")
        self.spec = ACTIONS.get(step.get("do"))
        self.step = step
        self.fields = {}

        head = Gtk.Box(spacing=8)
        num = Gtk.Label(label=str(index + 1))
        num.get_style_context().add_class("tc-step")
        head.pack_start(num, False, False, 0)
        icon = self.spec.icon if self.spec else "dialog-error-symbolic"
        head.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        title = Gtk.Label(label=self.spec.label if self.spec else f"Unknown: {step.get('do')}", xalign=0)
        title.get_style_context().add_class("tc-card-title")
        head.pack_start(title, True, True, 0)
        for icon_name, tip, cb, sensitive in (
            ("go-up-symbolic", "Move up", lambda *_: win.move_step(index, -1), index > 0),
            ("go-down-symbolic", "Move down", lambda *_: win.move_step(index, 1), index < total - 1),
            ("edit-copy-symbolic", "Duplicate", lambda *_: win.duplicate_step(index), True),
            ("user-trash-symbolic", "Remove", lambda *_: win.remove_step(index), True),
        ):
            b = Gtk.Button.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.set_tooltip_text(tip)
            b.set_sensitive(sensitive)
            b.connect("clicked", cb)
            head.pack_start(b, False, False, 0)
        self.pack_start(head, False, False, 0)

        if self.spec and self.spec.help:
            h = Gtk.Label(label=self.spec.help, xalign=0, wrap=True)
            h.set_opacity(0.6)
            self.pack_start(h, False, False, 0)

        if not self.spec:
            sw, get = _multiline(yaml.safe_dump(step, sort_keys=False), mono=True)
            self.raw = get
            self.pack_start(sw, False, False, 0)
            return

        grid = Gtk.Grid(column_spacing=10, row_spacing=6)
        for row, p in enumerate(self.spec.params + [SAVE_AS]):
            lbl = Gtk.Label(label=p.label, xalign=1, valign=Gtk.Align.START if p.kind in ("multiline", "actions") else Gtk.Align.CENTER)
            lbl.set_opacity(0.75)
            if p.help:
                lbl.set_tooltip_text(p.help)
            widget, getter = make_field(p, step.get(p.key, p.default if p.key != "save_as" else ""))
            widget.set_hexpand(p.kind not in ("bool", "number"))
            grid.attach(lbl, 0, row, 1, 1)
            grid.attach(widget, 1, row, 1, 1)
            self.fields[p.key] = (p, getter)
        self.pack_start(grid, False, False, 0)

    def collect(self) -> dict:
        if not self.spec:
            data = yaml.safe_load(self.raw()) or {}
            if not isinstance(data, dict):
                raise ShortcutError("an unknown step isn't a valid mapping")
            return data
        out = {"do": self.spec.name}
        for key, (p, get) in self.fields.items():
            v = get()
            if key == "save_as":
                if str(v).strip():
                    out["save_as"] = str(v).strip()
                continue
            if v == p.default or (v in ("", []) and p.default in ("", [])):
                continue
            out[key] = v
        return out


class ActionPicker(Gtk.Popover):
    def __init__(self, relative_to, on_pick):
        super().__init__(relative_to=relative_to, position=Gtk.PositionType.TOP)
        self.on_pick = on_pick
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=8)
        self.search = Gtk.SearchEntry(placeholder_text="search actions…")
        self.search.connect("search-changed", lambda *_: self.listbox.invalidate_filter())
        self.search.connect("activate", self._activate_first)
        box.pack_start(self.search, False, False, 0)
        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.listbox.set_filter_func(self._filter)
        self.listbox.set_header_func(self._header)
        self.listbox.connect("row-activated", lambda _lb, row: self._pick(row.spec.name))
        specs = sorted(ACTIONS.values(), key=lambda s: (CATEGORIES.index(s.category)
                                                         if s.category in CATEGORIES else 99, s.label))
        for s in specs:
            row = Gtk.ListBoxRow()
            row.spec = s
            hb = Gtk.Box(spacing=10, margin=6)
            hb.pack_start(Gtk.Image.new_from_icon_name(s.icon, Gtk.IconSize.MENU), False, False, 0)
            hb.pack_start(Gtk.Label(label=s.label, xalign=0), True, True, 0)
            row.add(hb)
            row.set_tooltip_text(s.help or s.name)
            self.listbox.add(row)
        sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        sw.set_size_request(300, 420)
        sw.add(self.listbox)
        box.pack_start(sw, True, True, 0)
        box.show_all()
        self.add(box)

    def popup_fresh(self):
        self.search.set_text("")
        self.popup()
        self.search.grab_focus()

    def _query(self):
        return self.search.get_text().strip().lower()

    def _filter(self, row):
        q = self._query()
        s = row.spec
        return not q or q in s.label.lower() or q in s.name or q in s.category.lower()

    def _header(self, row, before):
        if self._query() or (before and before.spec.category == row.spec.category):
            row.set_header(None)
            return
        lbl = Gtk.Label(label=row.spec.category.upper(), xalign=0)
        lbl.get_style_context().add_class("tc-cat")
        row.set_header(lbl)

    def _activate_first(self, *_):
        for row in self.listbox.get_children():
            if self._filter(row):
                self._pick(row.spec.name)
                return

    def _pick(self, name):
        self.popdown()
        self.on_pick(name)


class Window(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Tuxcuts")
        self.set_default_size(1060, 720)
        self.set_icon_name("system-run")
        self.current: dict | None = None
        self.snapshot = None
        self.steps: list[dict] = []
        self.cards: list[ActionCard] = []
        self.running = False

        # header bar
        hb = Gtk.HeaderBar(show_close_button=True, title="Tuxcuts",
                           subtitle=f"{system.session_type()} · {system.desktop() or 'linux'}")
        self.set_titlebar(hb)
        new_btn = Gtk.Button.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON)
        new_btn.set_tooltip_text("New shortcut (Ctrl+N)")
        new_btn.connect("clicked", lambda *_: self.new_shortcut())
        hb.pack_start(new_btn)

        self.run_btn = Gtk.Button(label="Run")
        self.run_btn.set_image(Gtk.Image.new_from_icon_name("media-playback-start-symbolic", Gtk.IconSize.BUTTON))
        self.run_btn.set_always_show_image(True)
        self.run_btn.get_style_context().add_class("suggested-action")
        self.run_btn.set_tooltip_text("Run (Ctrl+R)")
        self.run_btn.connect("clicked", lambda *_: self.run_current())
        self.save_btn = Gtk.Button(label="Save")
        self.save_btn.set_tooltip_text("Save (Ctrl+S)")
        self.save_btn.connect("clicked", lambda *_: self.save_current())

        menu = Gio.Menu()
        menu.append("Add to App Launcher", "win.launcher")
        menu.append("Set Hotkey…", "win.hotkey")
        menu.append("Edit as YAML…", "win.yaml")
        menu.append("Delete Shortcut", "win.delete")
        more = Gtk.MenuButton(menu_model=menu)
        more.set_image(Gtk.Image.new_from_icon_name("open-menu-symbolic", Gtk.IconSize.BUTTON))
        hb.pack_end(more)
        hb.pack_end(self.run_btn)
        hb.pack_end(self.save_btn)

        for name, cb, accel in (("new", self.new_shortcut, "<Primary>n"),
                                ("save", self.save_current, "<Primary>s"),
                                ("run", self.run_current, "<Primary>r"),
                                ("launcher", self.add_launcher, None),
                                ("hotkey", self.set_hotkey, None),
                                ("yaml", self.edit_yaml, None),
                                ("delete", self.delete_current, None)):
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", lambda *_a, cb=cb: cb())
            self.add_action(act)
            if accel:
                app.set_accels_for_action(f"win.{name}", [accel])

        # sidebar
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, position=260)
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.filter_entry = Gtk.SearchEntry(placeholder_text="search shortcuts", margin=8)
        self.filter_entry.connect("search-changed", lambda *_: self.sc_list.invalidate_filter())
        side.pack_start(self.filter_entry, False, False, 0)
        self.sc_list = Gtk.ListBox()
        self.sc_list.set_filter_func(self._sc_filter)
        self.sc_list.connect("row-selected", self._on_select)
        sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True)
        sw.add(self.sc_list)
        side.pack_start(sw, True, True, 0)
        paned.pack1(side, False, False)

        # editor
        editor = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        meta = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin=14, margin_bottom=4)
        self.name_entry = Gtk.Entry(placeholder_text="Shortcut name", has_frame=False)
        self.name_entry.get_style_context().add_class("tc-name")
        self.desc_entry = Gtk.Entry(placeholder_text="what does it do?", has_frame=False)
        meta.pack_start(self.name_entry, False, False, 0)
        meta.pack_start(self.desc_entry, False, False, 0)
        editor.pack_start(meta, False, False, 0)
        editor.pack_start(Gtk.Separator(), False, False, 0)

        self.steps_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=6, margin_bottom=6)
        self.steps_scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True)
        self.steps_scroll.add(self.steps_box)

        add_row = Gtk.Box(spacing=8, margin=10, halign=Gtk.Align.CENTER)
        self.add_btn = Gtk.Button(label="Add Action")
        self.add_btn.set_image(Gtk.Image.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON))
        self.add_btn.set_always_show_image(True)
        self.picker = ActionPicker(self.add_btn, self.add_step)
        self.add_btn.connect("clicked", lambda *_: self.picker.popup_fresh())
        add_row.pack_start(self.add_btn, False, False, 0)

        vpaned = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL, position=520)
        top = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        top.pack_start(self.steps_scroll, True, True, 0)
        top.pack_start(add_row, False, False, 0)
        vpaned.pack1(top, True, False)

        log_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        log_head = Gtk.Box(margin_start=12, margin_end=6)
        log_head.pack_start(Gtk.Label(label="Output", xalign=0), True, True, 0)
        clear = Gtk.Button.new_from_icon_name("edit-clear-all-symbolic", Gtk.IconSize.MENU)
        clear.set_relief(Gtk.ReliefStyle.NONE)
        clear.set_tooltip_text("Clear")
        clear.connect("clicked", lambda *_: self.log_buf.set_text(""))
        log_head.pack_start(clear, False, False, 0)
        log_box.pack_start(log_head, False, False, 0)
        self.log_view = Gtk.TextView(editable=False, cursor_visible=False, monospace=True,
                                     wrap_mode=Gtk.WrapMode.WORD_CHAR, left_margin=12, top_margin=6)
        self.log_buf = self.log_view.get_buffer()
        lsw = Gtk.ScrolledWindow()
        lsw.add(self.log_view)
        log_box.pack_start(lsw, True, True, 0)
        vpaned.pack2(log_box, False, True)

        editor.pack_start(vpaned, True, True, 0)
        self.editor = editor
        self.placeholder = Gtk.Label(label="pick a shortcut or hit + to make one 🐧")
        self.placeholder.get_style_context().add_class("tc-empty")
        self.stack = Gtk.Stack()
        self.stack.add_named(self.placeholder, "empty")
        self.stack.add_named(editor, "editor")
        paned.pack2(self.stack, True, False)
        self.add(paned)

        self.connect("delete-event", self._on_close)
        self.reload_list()
        self.show_all()
        self.stack.set_visible_child_name("empty")
        self._set_editing(False)

    # ── list ──────────────────────────────────────────────────────────────
    def reload_list(self, select_path=None):
        self._suppress_select = True
        for row in self.sc_list.get_children():
            self.sc_list.remove(row)
        for sc in engine.list_shortcuts():
            row = Gtk.ListBoxRow()
            row.sc = sc
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin=8, spacing=2)
            hb = Gtk.Box(spacing=8)
            hb.pack_start(Gtk.Image.new_from_icon_name(sc.get("icon") or "system-run", Gtk.IconSize.MENU), False, False, 0)
            name = Gtk.Label(label=str(sc["name"]), xalign=0, ellipsize=Pango.EllipsizeMode.END)
            name.get_style_context().add_class("tc-card-title")
            hb.pack_start(name, True, True, 0)
            box.pack_start(hb, False, False, 0)
            if sc.get("description"):
                d = Gtk.Label(label=str(sc["description"]), xalign=0, ellipsize=Pango.EllipsizeMode.END)
                d.set_opacity(0.6)
                box.pack_start(d, False, False, 0)
            row.add(box)
            self.sc_list.add(row)
            if select_path and sc.get("_path") == select_path:
                self.sc_list.select_row(row)
        self.sc_list.show_all()
        self._suppress_select = False

    def _sc_filter(self, row):
        q = self.filter_entry.get_text().strip().lower()
        return not q or q in str(row.sc["name"]).lower() or q in str(row.sc.get("description", "")).lower()

    def _on_select(self, _lb, row):
        if getattr(self, "_suppress_select", False) or row is None:
            return
        if self.current and row.sc.get("_path") == self.current.get("_path"):
            return
        if not self._maybe_save():
            self._suppress_select = True
            self._select_current_row()
            self._suppress_select = False
            return
        if row.sc.get("_broken"):
            self.toast(row.sc["description"], error=True)
        self.open_shortcut(copy.deepcopy(row.sc))
        self._suppress_select = True
        self._select_current_row()
        self._suppress_select = False

    def _select_current_row(self):
        for row in self.sc_list.get_children():
            if self.current and row.sc.get("_path") == self.current.get("_path"):
                self.sc_list.select_row(row)
                return
        self.sc_list.unselect_all()

    # ── editing ───────────────────────────────────────────────────────────
    def _set_editing(self, on: bool):
        for w in (self.run_btn, self.save_btn):
            w.set_sensitive(on)
        for name in ("save", "run", "launcher", "hotkey", "yaml", "delete"):
            self.lookup_action(name).set_enabled(on)

    def open_shortcut(self, sc: dict):
        self.current = sc
        self.name_entry.set_text(str(sc.get("name", "")))
        self.desc_entry.set_text(str(sc.get("description", "")))
        self.steps = list(sc.get("actions") or [])
        self.render_steps()
        self.snapshot = self._state()
        self.stack.set_visible_child_name("editor")
        self._set_editing(True)

    def new_shortcut(self):
        if not self._maybe_save():
            return
        names = {str(s["name"]).lower() for s in engine.list_shortcuts()}
        n, name = 1, "New Shortcut"
        while name.lower() in names:
            n += 1
            name = f"New Shortcut {n}"
        self.sc_list.unselect_all()
        self.open_shortcut({"name": name, "description": "", "actions": []})
        self.snapshot = None  # brand new = unsaved
        self.name_entry.grab_focus()

    def render_steps(self):
        for c in self.steps_box.get_children():
            self.steps_box.remove(c)
        self.cards = []
        if not self.steps:
            empty = Gtk.Label(label="no actions yet — hit Add Action 👇")
            empty.get_style_context().add_class("tc-empty")
            self.steps_box.pack_start(empty, False, False, 0)
        for i, step in enumerate(self.steps):
            card = ActionCard(self, step, i, len(self.steps))
            self.cards.append(card)
            self.steps_box.pack_start(card, False, False, 0)
        self.steps_box.show_all()

    def collect_steps(self) -> list[dict]:
        return [c.collect() for c in self.cards]

    def _sync(self) -> bool:
        try:
            self.steps = self.collect_steps()
            return True
        except ShortcutError as e:
            self.toast(str(e), error=True)
            return False

    def add_step(self, name):
        if not self._sync():
            return
        self.steps.append({"do": name})
        self.render_steps()
        GLib.idle_add(self._scroll_bottom)

    def _scroll_bottom(self):
        adj = self.steps_scroll.get_vadjustment()
        adj.set_value(adj.get_upper())
        return False

    def move_step(self, i, d):
        if self._sync() and 0 <= i + d < len(self.steps):
            self.steps[i], self.steps[i + d] = self.steps[i + d], self.steps[i]
            self.render_steps()

    def duplicate_step(self, i):
        if self._sync():
            self.steps.insert(i + 1, copy.deepcopy(self.steps[i]))
            self.render_steps()

    def remove_step(self, i):
        if self._sync():
            self.steps.pop(i)
            self.render_steps()

    def _state(self):
        try:
            return (self.name_entry.get_text().strip(), self.desc_entry.get_text().strip(),
                    yaml.safe_dump(self.collect_steps(), sort_keys=True))
        except ShortcutError:
            return ("__invalid__",)

    def build_current(self) -> dict:
        name = self.name_entry.get_text().strip()
        if not name:
            raise ShortcutError("give it a name first")
        sc = dict(self.current or {})
        sc.update(name=name, description=self.desc_entry.get_text().strip(), actions=self.collect_steps())
        return sc

    def save_current(self) -> bool:
        if not self.current:
            return False
        try:
            sc = self.build_current()
            path = engine.save(sc)
        except ShortcutError as e:
            self.toast(str(e), error=True)
            return False
        self.current = sc
        self.steps = sc["actions"]
        self.snapshot = self._state()
        self.reload_list(select_path=str(path))
        self.toast(f"saved {sc['name']} ✅")
        return True

    def _maybe_save(self) -> bool:
        """Before leaving the current shortcut: True means ok to move on."""
        if not self.current or self._state() == self.snapshot:
            return True
        dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                                text=f"save changes to '{self.name_entry.get_text() or 'Untitled'}'?")
        dlg.add_buttons("Discard", Gtk.ResponseType.REJECT, "Cancel", Gtk.ResponseType.CANCEL,
                        "Save", Gtk.ResponseType.ACCEPT)
        dlg.set_default_response(Gtk.ResponseType.ACCEPT)
        resp = dlg.run()
        dlg.destroy()
        if resp == Gtk.ResponseType.ACCEPT:
            return self.save_current()
        return resp == Gtk.ResponseType.REJECT

    def _on_close(self, *_):
        return not self._maybe_save()  # True blocks closing

    # ── running ───────────────────────────────────────────────────────────
    def log(self, msg):
        def add():
            end = self.log_buf.get_end_iter()
            self.log_buf.insert(end, msg + "\n")
            self.log_view.scroll_to_iter(self.log_buf.get_end_iter(), 0, False, 0, 1)
            return False
        GLib.idle_add(add)

    def toast(self, msg, error=False):
        self.log(("⚠ " if error else "") + msg)
        if error:
            dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.ERROR,
                                    buttons=Gtk.ButtonsType.OK, text=msg)
            dlg.run()
            dlg.destroy()

    def run_current(self):
        if self.running or not self.current:
            return
        try:
            sc = self.build_current()
            engine.validate(sc["actions"])
        except ShortcutError as e:
            self.toast(str(e), error=True)
            return
        self.running = True
        self.run_btn.set_sensitive(False)
        self.log(f"▶ {sc['name']}")

        def work():
            try:
                result = engine.run_shortcut(sc, "", log=self.log)
                if result not in (None, ""):
                    self.log(f"= {result}")
                self.log("✓ done\n")
            except ShortcutError as e:
                self.log(f"✗ {e}\n")
            except Exception as e:  # keep the app alive whatever happens
                self.log(f"✗ {type(e).__name__}: {e}\n")
            finally:
                GLib.idle_add(self._run_done)
        threading.Thread(target=work, daemon=True).start()

    def _run_done(self):
        self.running = False
        self.run_btn.set_sensitive(True)
        return False

    # ── menu actions ──────────────────────────────────────────────────────
    def _need_saved(self) -> dict | None:
        if self._state() != self.snapshot and not self.save_current():
            return None
        return self.current

    def add_launcher(self):
        sc = self._need_saved()
        if sc:
            path = integrations.make_launcher(sc)
            self.toast(f"added to app launcher → {path.name}")

    def set_hotkey(self):
        sc = self._need_saved()
        if not sc:
            return
        dlg = Gtk.Dialog(title="Set Hotkey", transient_for=self, modal=True)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Bind", Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)
        area = dlg.get_content_area()
        area.set_spacing(8)
        area.set_border_width(14)
        area.add(Gtk.Label(label="press the combo, or type it like super+shift+n", xalign=0))
        entry = Gtk.Entry(activates_default=True, placeholder_text="super+shift+n")

        def on_key(_w, ev):
            keyname = Gdk.keyval_name(ev.keyval) or ""
            if keyname in ("Tab", "Return", "KP_Enter", "BackSpace", "Escape") and not ev.state & (
                    Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.SUPER_MASK | Gdk.ModifierType.MOD1_MASK):
                return False
            if keyname.startswith(("Control", "Shift", "Alt", "Super", "Meta", "ISO_")):
                return True
            mods = []
            if ev.state & Gdk.ModifierType.SUPER_MASK:
                mods.append("super")
            if ev.state & Gdk.ModifierType.CONTROL_MASK:
                mods.append("ctrl")
            if ev.state & Gdk.ModifierType.MOD1_MASK:
                mods.append("alt")
            if ev.state & Gdk.ModifierType.SHIFT_MASK:
                mods.append("shift")
            if not mods:
                return False
            entry.set_text("+".join(mods + [keyname.lower()]))
            entry.set_position(-1)
            return True
        entry.connect("key-press-event", on_key)
        area.add(entry)
        dlg.show_all()
        resp = dlg.run()
        keys = entry.get_text().strip()
        dlg.destroy()
        if resp != Gtk.ResponseType.OK or not keys:
            return
        try:
            msg = integrations.bind_hotkey(sc, keys)
        except Exception as e:
            self.toast(f"couldn't bind: {e}", error=True)
            return
        info = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
                                 buttons=Gtk.ButtonsType.OK, text="Hotkey")
        info.format_secondary_text(msg)
        for child in info.get_message_area().get_children():
            if isinstance(child, Gtk.Label):
                child.set_selectable(True)
        info.run()
        info.destroy()

    def edit_yaml(self):
        try:
            sc = self.build_current()
        except ShortcutError as e:
            self.toast(str(e), error=True)
            return
        dlg = Gtk.Dialog(title="Edit as YAML", transient_for=self, modal=True)
        dlg.set_default_size(620, 560)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Apply", Gtk.ResponseType.OK)
        sw, get = _multiline(yaml.safe_dump(engine.clean(sc), sort_keys=False, allow_unicode=True),
                             mono=True, height=480)
        sw.set_vexpand(True)
        dlg.get_content_area().pack_start(sw, True, True, 0)
        dlg.show_all()
        while dlg.run() == Gtk.ResponseType.OK:
            try:
                data = yaml.safe_load(get())
                if not isinstance(data, dict):
                    raise ShortcutError("should be a mapping with name / actions")
                engine.validate(data.get("actions"))
            except (yaml.YAMLError, ShortcutError) as e:
                self.toast(f"not quite: {e}", error=True)
                continue
            data["_path"] = self.current.get("_path")
            snap = self.snapshot
            self.open_shortcut(data)
            self.snapshot = snap  # still unsaved
            break
        dlg.destroy()

    def delete_current(self):
        if not self.current:
            return
        name = self.current.get("name")
        dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.WARNING,
                                text=f"delete '{name}'?")
        dlg.format_secondary_text("this can't be undone")
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Delete", Gtk.ResponseType.ACCEPT)
        dlg.get_widget_for_response(Gtk.ResponseType.ACCEPT).get_style_context().add_class("destructive-action")
        resp = dlg.run()
        dlg.destroy()
        if resp != Gtk.ResponseType.ACCEPT:
            return
        engine.delete(self.current)
        (integrations.APPS_DIR / f"tuxcut-{engine.slugify(str(name))}.desktop").unlink(missing_ok=True)
        self.current = None
        self.snapshot = None
        self.reload_list()
        self.stack.set_visible_child_name("empty")
        self._set_editing(False)
        self.toast(f"deleted {name}")


class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.win = None

    def do_startup(self):
        Gtk.Application.do_startup(self)
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def do_activate(self):
        if not self.win:
            self.win = Window(self)
        self.win.present()


def main():
    sys.exit(App().run(sys.argv[:1]))


if __name__ == "__main__":
    main()
