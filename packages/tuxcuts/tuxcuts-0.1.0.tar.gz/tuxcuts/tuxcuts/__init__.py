"""Tuxcuts — Apple Shortcuts vibes for Linux."""
__version__ = "0.1.0"
