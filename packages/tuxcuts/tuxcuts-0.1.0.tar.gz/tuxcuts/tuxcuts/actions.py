"""The built-in action catalog."""
from __future__ import annotations

import ast
import json
import operator
import os
import re
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

from . import system as S
from .engine import Context, Param, action, run_actions
from .system import ShortcutError, StopShortcut

R = "{{result}}"


def _num(v):
    try:
        f = float(v)
        return int(f) if f.is_integer() else f
    except (TypeError, ValueError):
        return v


# ── Text ───────────────────────────────────────────────────────────────────

@action("text", "Text", "Text", "format-text-plain-symbolic",
        "Makes some text. Use {{result}}, {{date}}, {{clipboard}} or any variable inside.",
        [Param("content", "Text", "multiline")])
def a_text(ctx, content):
    return content


@action("replace_text", "Replace Text", "Text", "edit-find-replace-symbolic", "",
        [Param("text", "In", default=R), Param("find", "Find"), Param("replace", "Replace with"),
         Param("regex", "Regular expression", "bool", False),
         Param("ignore_case", "Ignore case", "bool", False)])
def a_replace(ctx, text, find, replace, regex, ignore_case):
    flags = re.I if ignore_case else 0
    pattern = find if regex else re.escape(find)
    try:
        return re.sub(pattern, replace if regex else replace.replace("\\", "\\\\"), text, flags=flags)
    except re.error as e:
        raise ShortcutError(f"bad regex: {e}")


@action("change_case", "Change Case", "Text", "format-text-uppercase-symbolic", "",
        [Param("text", "Text", default=R),
         Param("case", "Case", "choice", "upper", ["upper", "lower", "title", "sentence", "swap"])])
def a_case(ctx, text, case):
    if case == "sentence":
        return text[:1].upper() + text[1:].lower()
    return {"upper": str.upper, "lower": str.lower, "title": str.title, "swap": str.swapcase}[case](text)


@action("trim", "Trim Whitespace", "Text", "format-justify-left-symbolic", "",
        [Param("text", "Text", default=R)])
def a_trim(ctx, text):
    return text.strip()


@action("count", "Count", "Text", "accessories-calculator-symbolic", "",
        [Param("text", "Text", default=R),
         Param("what", "Count", "choice", "words", ["characters", "words", "lines"])])
def a_count(ctx, text, what):
    if what == "characters":
        return len(text)
    if what == "lines":
        return len(text.splitlines())
    return len(text.split())


@action("split_text", "Get Line", "Text", "view-list-symbolic",
        "Pick one line/item. 1 = first, -1 = last.",
        [Param("text", "Text", default=R), Param("separator", "Split on", default="\\n"),
         Param("index", "Item number", "number", 1)])
def a_split(ctx, text, separator, index):
    sep = separator.encode().decode("unicode_escape") or "\n"
    parts = text.split(sep)
    i = int(index)
    i = i - 1 if i > 0 else i
    try:
        return parts[i]
    except IndexError:
        return ""


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
        ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUNCS = {"round": round, "abs": abs, "min": min, "max": max, "int": int}


def _calc(node):
    if isinstance(node, ast.Expression):
        return _calc(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        left, right = _calc(node.left), _calc(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 1000:
            raise ShortcutError("exponent too big")
        return _OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_calc(node.operand))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUNCS:
        return _FUNCS[node.func.id](*[_calc(a) for a in node.args])
    raise ShortcutError("calculate only does numbers and + - * / // % ** round abs min max")


@action("calculate", "Calculate", "Text", "accessories-calculator-symbolic",
        "Math like {{result}} * 60 or round({{total}} / 3, 2)",
        [Param("expression", "Expression", default=R)])
def a_calc(ctx, expression):
    try:
        val = _calc(ast.parse(expression.strip(), mode="eval"))
    except SyntaxError:
        raise ShortcutError(f"can't do math on {expression!r}")
    except ZeroDivisionError:
        raise ShortcutError("divided by zero 💀")
    return _num(val)


@action("random_number", "Random Number", "Text", "media-playlist-shuffle-symbolic", "",
        [Param("min", "Min", "number", 1), Param("max", "Max", "number", 100)])
def a_random(ctx, min, max):
    import random
    return random.randint(int(min), int(max))


@action("get_json_value", "Get JSON Value", "Text", "text-x-script-symbolic",
        "Dig into JSON with a path like data.items.0.name",
        [Param("data", "JSON", default=R), Param("path", "Path")])
def a_json(ctx, data, path):
    try:
        cur = json.loads(data)
    except json.JSONDecodeError:
        raise ShortcutError("that's not valid JSON")
    for part in [p for p in path.split(".") if p]:
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return ""
        elif isinstance(cur, dict):
            cur = cur.get(part, "")
        else:
            return ""
    return cur if isinstance(cur, str) else json.dumps(cur) if isinstance(cur, (dict, list)) else _num(cur)


# ── Variables ──────────────────────────────────────────────────────────────

@action("set_variable", "Set Variable", "Variables", "document-edit-symbolic",
        "Keeps a value as {{name}} for later steps.",
        [Param("name", "Name"), Param("value", "Value", default=R)])
def a_setvar(ctx, name, value):
    if not name:
        raise ShortcutError("Set Variable needs a name")
    ctx.vars[name] = value
    return None


@action("get_variable", "Get Variable", "Variables", "document-open-symbolic", "",
        [Param("name", "Name")])
def a_getvar(ctx, name):
    return ctx.vars.get(name, "")


# ── Dialogs ────────────────────────────────────────────────────────────────

@action("ask_input", "Ask for Input", "Dialogs", "dialog-question-symbolic", "",
        [Param("prompt", "Prompt", default="Type something"), Param("default", "Default answer")])
def a_ask(ctx, prompt, default):
    return S.ask_text(prompt, default)


@action("choose_from_list", "Choose from List", "Dialogs", "view-list-bullet-symbolic",
        "One option per line.",
        [Param("prompt", "Prompt", default="Pick one"), Param("items", "Options", "multiline")])
def a_choose(ctx, prompt, items):
    return S.choose(prompt, [i for i in items.splitlines() if i.strip()])


@action("confirm", "Ask Before Continuing", "Dialogs", "dialog-warning-symbolic",
        "Stops the shortcut if you say no.",
        [Param("prompt", "Question", default="Keep going?")])
def a_confirm(ctx, prompt):
    if not S.confirm(prompt):
        raise StopShortcut("said no")
    return None


@action("show_result", "Show Result", "Dialogs", "dialog-information-symbolic", "",
        [Param("title", "Title", default="Result"), Param("text", "Text", "multiline", R)])
def a_show(ctx, title, text):
    S.show_text(title, text)
    return None


@action("notify", "Show Notification", "Dialogs", "preferences-system-notifications-symbolic", "",
        [Param("title", "Title", default="Tuxcuts"), Param("body", "Body", default=R)])
def a_notify(ctx, title, body):
    S.notify(title, body)
    return None


# ── Clipboard ──────────────────────────────────────────────────────────────

@action("clipboard_get", "Get Clipboard", "Clipboard", "edit-paste-symbolic")
def a_clip_get(ctx):
    return S.clipboard_get()


@action("clipboard_set", "Copy to Clipboard", "Clipboard", "edit-copy-symbolic", "",
        [Param("text", "Text", default=R)])
def a_clip_set(ctx, text):
    S.clipboard_set(text)
    return None


# ── Keyboard ───────────────────────────────────────────────────────────────

@action("type_text", "Type Text", "Keyboard", "input-keyboard-symbolic",
        "Types into whatever window is focused.",
        [Param("text", "Text", default=R)])
def a_type(ctx, text):
    S.type_text(text)
    return None


@action("press_keys", "Press Keys", "Keyboard", "preferences-desktop-keyboard-shortcuts-symbolic",
        "Like ctrl+shift+t or super+l",
        [Param("keys", "Keys", default="ctrl+c")])
def a_keys(ctx, keys):
    S.press_keys(keys)
    return None


# ── Web ────────────────────────────────────────────────────────────────────

@action("open_url", "Open URL", "Web", "web-browser-symbolic", "",
        [Param("url", "URL", default="https://")])
def a_open_url(ctx, url):
    S.open_target(url)
    return None


@action("http_request", "Get Contents of URL", "Web", "network-transmit-receive-symbolic",
        "Headers: one 'Key: value' per line.",
        [Param("url", "URL", default="https://"),
         Param("method", "Method", "choice", "GET", ["GET", "POST", "PUT", "PATCH", "DELETE"]),
         Param("body", "Body", "multiline"), Param("headers", "Headers", "multiline")])
def a_http(ctx, url, method, body, headers):
    hdrs = {"User-Agent": "curl/8 (tuxcuts)"}
    for line in headers.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            hdrs[k.strip()] = v.strip()
    req = urllib.request.Request(url, data=body.encode() if body else None, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read().decode(r.headers.get_content_charset() or "utf-8", "replace").strip()
    except urllib.error.HTTPError as e:
        raise ShortcutError(f"{url} said {e.code} {e.reason}")
    except (urllib.error.URLError, OSError) as e:
        raise ShortcutError(f"couldn't reach {url}: {getattr(e, 'reason', e)}")


# ── Files ──────────────────────────────────────────────────────────────────

@action("read_file", "Read File", "Files", "document-open-symbolic", "",
        [Param("path", "Path")])
def a_read(ctx, path):
    p = Path(os.path.expanduser(path))
    try:
        return p.read_text(errors="replace").rstrip("\n")
    except OSError as e:
        raise ShortcutError(f"can't read {p}: {e.strerror}")


@action("save_file", "Save File", "Files", "document-save-symbolic", "",
        [Param("path", "Path"), Param("content", "Content", "multiline", R),
         Param("append", "Add to end instead of replacing", "bool", False)])
def a_save(ctx, path, content, append):
    p = Path(os.path.expanduser(path))
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a" if append else "w") as f:
        f.write(content if content.endswith("\n") else content + "\n")
    return str(p)


@action("open_file", "Open File or Folder", "Files", "folder-open-symbolic", "",
        [Param("path", "Path", default=R)])
def a_open_file(ctx, path):
    S.open_target(os.path.expanduser(path))
    return None


# ── Apps ───────────────────────────────────────────────────────────────────

@action("open_app", "Open App", "Apps", "application-x-executable-symbolic",
        "App id (firefox, org.gnome.Nautilus) or a command.",
        [Param("app", "App")])
def a_open_app(ctx, app):
    S.open_app(app)
    return None


@action("run_command", "Run Shell Script", "Apps", "utilities-terminal-symbolic",
        "Output becomes the result. Input is passed on stdin when enabled.",
        [Param("command", "Script", "multiline"),
         Param("pass_input", "Send result as input", "bool", False),
         Param("ignore_errors", "Keep going on error", "bool", False)])
def a_shell(ctx, command, pass_input, ignore_errors):
    p = subprocess.run(command, shell=True, executable="/bin/bash" if Path("/bin/bash").exists() else None,
                       input=str(ctx.result) if pass_input else None, capture_output=True, text=True)
    if p.returncode != 0 and not ignore_errors:
        raise ShortcutError(f"script failed ({p.returncode}): {p.stderr.strip()[:300]}")
    return p.stdout.rstrip("\n")


@action("screenshot", "Take Screenshot", "Apps", "camera-photo-symbolic",
        "Returns the file path.",
        [Param("mode", "Capture", "choice", "full screen", ["full screen", "pick an area"]),
         Param("path", "Save to (blank = ~/Pictures/Screenshots)")])
def a_shot(ctx, mode, path):
    return S.screenshot(mode == "pick an area", path)


# ── System / Media ─────────────────────────────────────────────────────────

@action("volume", "Set Volume", "Media", "audio-volume-high-symbolic",
        "50 sets it, +5 / -5 nudges, or mute / unmute / toggle",
        [Param("level", "Level", default="50")])
def a_volume(ctx, level):
    S.set_volume(level)
    return None


@action("media", "Media Control", "Media", "media-playback-start-symbolic", "",
        [Param("command", "Do", "choice", "play-pause", ["play-pause", "play", "pause", "next", "previous", "stop"])])
def a_media(ctx, command):
    S.media(command)
    return None


@action("brightness", "Set Brightness", "System", "display-brightness-symbolic",
        "70 sets it, +10 / -10 nudges",
        [Param("level", "Level", default="70")])
def a_bright(ctx, level):
    S.set_brightness(level)
    return None


@action("lock_screen", "Lock Screen", "System", "system-lock-screen-symbolic")
def a_lock(ctx):
    S.lock_screen()
    return None


# ── Flow ───────────────────────────────────────────────────────────────────

CONDITIONS = ["contains", "doesn't contain", "is", "is not", "is empty", "is not empty",
              "starts with", "ends with", "matches regex", "is greater than", "is less than"]


def _check(left: str, op: str, right: str) -> bool:
    if op in ("is greater than", "is less than"):
        try:
            a, b = float(left), float(right)
        except ValueError:
            raise ShortcutError(f"can't compare {left!r} and {right!r} as numbers")
        return a > b if op == "is greater than" else a < b
    return {
        "contains": lambda: right in left,
        "doesn't contain": lambda: right not in left,
        "is": lambda: left == right,
        "is not": lambda: left != right,
        "is empty": lambda: not left.strip(),
        "is not empty": lambda: bool(left.strip()),
        "starts with": lambda: left.startswith(right),
        "ends with": lambda: left.endswith(right),
        "matches regex": lambda: re.search(right, left) is not None,
    }[op]()


@action("if", "If", "Flow", "media-playlist-consecutive-symbolic",
        "Runs 'then' or 'otherwise' steps.",
        [Param("value", "If", default=R),
         Param("condition", "Condition", "choice", "contains", CONDITIONS),
         Param("compare_to", "This"),
         Param("then", "Then", "actions", []),
         Param("otherwise", "Otherwise", "actions", [])])
def a_if(ctx, value, condition, compare_to, then, otherwise):
    branch = then if _check(value, condition, compare_to) else otherwise
    ctx.depth += 1
    try:
        run_actions(branch or [], ctx)
    finally:
        ctx.depth -= 1
    return None


@action("repeat", "Repeat", "Flow", "media-playlist-repeat-symbolic",
        "{{repeat_index}} counts up from 1. Result = each round's output, one per line.",
        [Param("times", "Times", "number", 3), Param("actions", "Steps", "actions", [])])
def a_repeat(ctx, times, actions):
    outs = []
    ctx.depth += 1
    try:
        for i in range(1, int(times) + 1):
            ctx.vars["repeat_index"] = i
            outs.append(str(run_actions(actions or [], ctx)))
    finally:
        ctx.depth -= 1
    return "\n".join(outs)


@action("repeat_each", "Repeat with Each Line", "Flow", "media-playlist-shuffle-symbolic",
        "{{item}} is the current line, {{repeat_index}} its number.",
        [Param("list", "Lines", "multiline", R), Param("actions", "Steps", "actions", [])])
def a_each(ctx, list, actions):
    outs = []
    ctx.depth += 1
    try:
        for i, item in enumerate([l for l in list.splitlines() if l.strip()], 1):
            ctx.vars["item"], ctx.vars["repeat_index"] = item, i
            ctx.result = item
            outs.append(str(run_actions(actions or [], ctx)))
    finally:
        ctx.depth -= 1
    return "\n".join(outs)


@action("wait", "Wait", "Flow", "alarm-symbolic", "",
        [Param("seconds", "Seconds", "number", 1)])
def a_wait(ctx, seconds):
    time.sleep(max(0, float(seconds)))
    return None


@action("stop", "Stop Shortcut", "Flow", "process-stop-symbolic")
def a_stop(ctx):
    raise StopShortcut("")


@action("run_shortcut", "Run Shortcut", "Flow", "emblem-symbolic-link-symbolic",
        "Runs another shortcut, passing the result as its input.",
        [Param("name", "Shortcut"), Param("input", "Input", default=R)])
def a_run_sc(ctx, name, input):
    from .engine import find, run_shortcut
    return run_shortcut(find(name), input, parent=ctx)


@action("comment", "Comment", "Flow", "user-available-symbolic",
        "Does nothing — notes to self.",
        [Param("note", "Note", "multiline")])
def a_comment(ctx, note):
    return None
