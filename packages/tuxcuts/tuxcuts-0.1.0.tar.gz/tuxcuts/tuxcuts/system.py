"""Talks to the desktop: clipboard, dialogs, typing, screenshots, audio.

Every helper picks the right tool for the session (Wayland or X11) and the
desktop (GNOME, KDE, wlroots…), falling back down a list until one works.
"""
from __future__ import annotations

import html
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


class ShortcutError(Exception):
    """Something went wrong while running a shortcut."""


class StopShortcut(Exception):
    """Ends a shortcut early (user cancelled, or a Stop action)."""


# ── environment ────────────────────────────────────────────────────────────

def session_type() -> str:
    s = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if s in ("wayland", "x11"):
        return s
    if os.environ.get("WAYLAND_DISPLAY"):
        return "wayland"
    if os.environ.get("DISPLAY"):
        return "x11"
    return "tty"


def desktop() -> str:
    return (os.environ.get("XDG_CURRENT_DESKTOP") or os.environ.get("DESKTOP_SESSION") or "").lower()


def is_gnome() -> bool:
    return "gnome" in desktop()


def is_kde() -> bool:
    d = desktop()
    return "kde" in d or "plasma" in d


def have(tool: str) -> bool:
    return shutil.which(tool) is not None


def run(args, input_text=None, check=True) -> str:
    try:
        p = subprocess.run(args, input=input_text, capture_output=True, text=True)
    except FileNotFoundError:
        raise ShortcutError(f"'{args[0]}' isn't installed")
    if check and p.returncode != 0:
        msg = (p.stderr or "").strip() or f"exit code {p.returncode}"
        raise ShortcutError(f"{args[0]} failed: {msg}")
    return p.stdout.rstrip("\n")


def detach(args) -> None:
    """Start something and don't wait for it (apps, URLs)."""
    try:
        subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    except FileNotFoundError:
        raise ShortcutError(f"'{args[0]}' isn't installed")


# ── clipboard ──────────────────────────────────────────────────────────────

def clipboard_get() -> str:
    order = [("wl-paste", ["wl-paste", "--no-newline"]),
             ("xclip", ["xclip", "-selection", "clipboard", "-o"]),
             ("xsel", ["xsel", "--clipboard", "--output"])]
    if session_type() != "wayland":
        order = order[1:] + order[:1]
    for tool, args in order:
        if have(tool):
            return run(args, check=False)
    raise ShortcutError("no clipboard tool — install wl-clipboard (Wayland) or xclip (X11)")


def clipboard_set(text: str) -> None:
    order = [("wl-copy", ["wl-copy"]),
             ("xclip", ["xclip", "-selection", "clipboard", "-i"]),
             ("xsel", ["xsel", "--clipboard", "--input"])]
    if session_type() != "wayland":
        order = order[1:] + order[:1]
    for tool, args in order:
        if have(tool):
            # these fork to keep owning the clipboard, so don't capture output
            subprocess.run(args, input=text, text=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    raise ShortcutError("no clipboard tool — install wl-clipboard (Wayland) or xclip (X11)")


# ── dialogs ────────────────────────────────────────────────────────────────

def dialog_tool() -> str | None:
    if is_kde() and have("kdialog"):
        return "kdialog"
    for t in ("zenity", "kdialog", "yad"):
        if have(t):
            return t
    return None


def _tty() -> bool:
    return sys.stdin is not None and sys.stdin.isatty()


def _no_dialog():
    raise ShortcutError("no dialog tool — install zenity (or kdialog / yad)")


def ask_text(prompt: str, default: str = "") -> str:
    t = dialog_tool()
    if t in ("zenity", "yad"):
        args = [t, "--entry", "--title=Tuxcuts", f"--text={html.escape(prompt)}", f"--entry-text={default}"]
    elif t == "kdialog":
        args = ["kdialog", "--title", "Tuxcuts", "--inputbox", prompt, default]
    elif _tty():
        ans = input(f"{prompt} ")
        return ans or default
    else:
        _no_dialog()
    p = subprocess.run(args, capture_output=True, text=True)
    if p.returncode != 0:
        raise StopShortcut("cancelled")
    return p.stdout.rstrip("\n")


def choose(prompt: str, items: list[str]) -> str:
    if not items:
        raise ShortcutError("nothing to choose from")
    t = dialog_tool()
    if t in ("zenity", "yad"):
        args = [t, "--list", "--title=Tuxcuts", f"--text={html.escape(prompt)}",
                "--column=Pick", "--width=380", "--height=420"]
        args += ["--hide-header"] if t == "zenity" else ["--no-headers"]
        p = subprocess.run(args + items, capture_output=True, text=True)
        if p.returncode != 0 or not p.stdout.strip():
            raise StopShortcut("cancelled")
        return p.stdout.strip().split("|")[0]
    if t == "kdialog":
        args = ["kdialog", "--title", "Tuxcuts", "--menu", prompt]
        for i, item in enumerate(items):
            args += [str(i), item]
        p = subprocess.run(args, capture_output=True, text=True)
        if p.returncode != 0:
            raise StopShortcut("cancelled")
        return items[int(p.stdout.strip())]
    if _tty():
        print(prompt)
        for i, item in enumerate(items, 1):
            print(f"  {i}. {item}")
        while True:
            ans = input("> ").strip()
            if ans.isdigit() and 1 <= int(ans) <= len(items):
                return items[int(ans) - 1]
            if ans in items:
                return ans
    _no_dialog()


def confirm(prompt: str) -> bool:
    t = dialog_tool()
    if t == "zenity":
        args = ["zenity", "--question", "--title=Tuxcuts", f"--text={html.escape(prompt)}"]
    elif t == "kdialog":
        args = ["kdialog", "--title", "Tuxcuts", "--yesno", prompt]
    elif t == "yad":
        args = ["yad", "--title=Tuxcuts", f"--text={html.escape(prompt)}", "--button=No:1", "--button=Yes:0"]
    elif _tty():
        return input(f"{prompt} [y/N] ").strip().lower() in ("y", "yes")
    else:
        _no_dialog()
    return subprocess.run(args).returncode == 0


def show_text(title: str, text: str) -> None:
    t = dialog_tool()
    if t in ("zenity", "yad"):
        subprocess.run([t, "--text-info", f"--title={title}", "--width=520", "--height=380"],
                       input=text, text=True, capture_output=True)
    elif t == "kdialog":
        subprocess.run(["kdialog", "--title", title, "--msgbox", text])
    else:
        print(f"── {title} ──\n{text}")


def notify(title: str, body: str = "") -> None:
    if have("notify-send"):
        subprocess.run(["notify-send", "-a", "Tuxcuts", title, body])
    elif have("kdialog"):
        subprocess.run(["kdialog", "--title", title, "--passivepopup", body or title, "5"])
    else:
        print(f"🔔 {title}" + (f" — {body}" if body else ""), file=sys.stderr)


# ── keyboard ───────────────────────────────────────────────────────────────

KEY_NAMES = {
    "enter": "Return", "return": "Return", "esc": "Escape", "escape": "Escape",
    "tab": "Tab", "space": "space", "backspace": "BackSpace", "delete": "Delete",
    "del": "Delete", "insert": "Insert", "up": "Up", "down": "Down", "left": "Left",
    "right": "Right", "home": "Home", "end": "End", "pageup": "Page_Up",
    "pagedown": "Page_Down", **{f"f{i}": f"F{i}" for i in range(1, 13)},
}

# Linux input keycodes, for ydotool (the only typer that works on GNOME Wayland)
KEYCODES = {
    "esc": 1, "escape": 1, "minus": 12, "equal": 13, "backspace": 14, "tab": 15,
    "enter": 28, "return": 28, "ctrl": 29, "control": 29, "shift": 42, "alt": 56,
    "space": 57, "super": 125, "win": 125, "meta": 125, "home": 102, "up": 103,
    "pageup": 104, "left": 105, "right": 106, "end": 107, "down": 108,
    "pagedown": 109, "insert": 110, "delete": 111, "del": 111,
    **{str(i): i + 1 for i in range(1, 10)}, "0": 11,
    **{c: n for n, c in enumerate("qwertyuiop", 16)},
    **{c: n for n, c in enumerate("asdfghjkl", 30)},
    **{c: n for n, c in enumerate("zxcvbnm", 44)},
    **{f"f{i}": 58 + i for i in range(1, 11)}, "f11": 87, "f12": 88,
}

_MODS = {"ctrl": "ctrl", "control": "ctrl", "shift": "shift", "alt": "alt",
         "super": "super", "win": "super", "meta": "super", "logo": "super"}


def _parse_combo(combo: str):
    parts = [p.strip().lower() for p in combo.split("+") if p.strip()]
    if not parts:
        raise ShortcutError("no keys given")
    return [_MODS.get(p, p) for p in parts[:-1]], parts[-1]


def type_text(text: str) -> None:
    s = session_type()
    if s == "wayland":
        tools = ["ydotool", "wtype"] if is_gnome() else ["wtype", "ydotool"]
        for tool in tools:
            if have(tool):
                run([tool, "type", text] if tool == "ydotool" else ["wtype", text])
                return
        raise ShortcutError("install wtype or ydotool to type on Wayland (GNOME needs ydotool)")
    if have("xdotool"):
        run(["xdotool", "type", "--delay", "12", text])
        return
    raise ShortcutError("install xdotool to type on X11")


def press_keys(combo: str) -> None:
    mods, key = _parse_combo(combo)
    s = session_type()
    if s == "x11" and have("xdotool"):
        run(["xdotool", "key", "+".join(mods + [KEY_NAMES.get(key, key)])])
        return
    if s == "wayland" and have("wtype") and not is_gnome():
        args = ["wtype"]
        for m in mods:
            args += ["-M", "logo" if m == "super" else m]
        args += ["-k", KEY_NAMES.get(key, key)]
        for m in reversed(mods):
            args += ["-m", "logo" if m == "super" else m]
        run(args)
        return
    if have("ydotool"):
        codes = []
        for k in mods + [key]:
            if k not in KEYCODES:
                raise ShortcutError(f"ydotool doesn't know the key '{k}'")
            codes.append(KEYCODES[k])
        seq = [f"{c}:1" for c in codes] + [f"{c}:0" for c in reversed(codes)]
        run(["ydotool", "key", *seq])
        return
    raise ShortcutError("install xdotool (X11), wtype or ydotool (Wayland) to press keys")


# ── screenshots ────────────────────────────────────────────────────────────

def screenshot(area: bool, path: str = "") -> str:
    if path:
        out = Path(os.path.expanduser(path))
    else:
        out = Path.home() / "Pictures" / "Screenshots" / time.strftime("tuxcut-%Y%m%d-%H%M%S.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    s = session_type()
    if is_kde() and have("spectacle"):
        run(["spectacle", "-b", "-n", "-r" if area else "-f", "-o", str(out)])
    elif s == "wayland" and have("grim") and not is_gnome():
        if area:
            if not have("slurp"):
                raise ShortcutError("install slurp to pick an area")
            geo = subprocess.run(["slurp"], capture_output=True, text=True)
            if geo.returncode != 0:
                raise StopShortcut("cancelled")
            run(["grim", "-g", geo.stdout.strip(), str(out)])
        else:
            run(["grim", str(out)])
    elif have("gnome-screenshot"):
        run(["gnome-screenshot", "-a", "-f", str(out)] if area
            else ["gnome-screenshot", "-f", str(out)])
    elif s == "x11" and have("maim"):
        run(["maim", "-s", str(out)] if area else ["maim", str(out)])
    elif s == "x11" and have("scrot"):
        run(["scrot", "-s", str(out)] if area else ["scrot", str(out)])
    else:
        raise ShortcutError("no screenshot tool — install grim+slurp, maim, scrot, spectacle or gnome-screenshot")
    if not out.exists():
        raise StopShortcut("screenshot cancelled")
    return str(out)


# ── audio / display / media ────────────────────────────────────────────────

def set_volume(level: str) -> None:
    level = str(level).strip().lower().rstrip("%")
    if have("wpctl"):
        sink = "@DEFAULT_AUDIO_SINK@"
        if level in ("mute", "unmute", "toggle"):
            run(["wpctl", "set-mute", sink, {"mute": "1", "unmute": "0", "toggle": "toggle"}[level]])
        elif level[:1] in "+-":
            run(["wpctl", "set-volume", "-l", "1.0", sink, f"{level[1:]}%{level[0]}"])
        else:
            run(["wpctl", "set-volume", sink, f"{level}%"])
    elif have("pactl"):
        sink = "@DEFAULT_SINK@"
        if level in ("mute", "unmute", "toggle"):
            run(["pactl", "set-sink-mute", sink, {"mute": "1", "unmute": "0", "toggle": "toggle"}[level]])
        else:
            run(["pactl", "set-sink-volume", sink, f"{level}%"])
    else:
        raise ShortcutError("install wireplumber (wpctl) or pulseaudio-utils (pactl)")


def set_brightness(level: str) -> None:
    level = str(level).strip().rstrip("%")
    if not have("brightnessctl"):
        raise ShortcutError("install brightnessctl")
    if level[:1] in "+-":
        run(["brightnessctl", "set", f"{level[1:]}%{level[0]}"])
    else:
        run(["brightnessctl", "set", f"{level}%"])


def media(command: str) -> None:
    if not have("playerctl"):
        raise ShortcutError("install playerctl")
    run(["playerctl", command], check=False)


def lock_screen() -> None:
    for args in (["loginctl", "lock-session"], ["xdg-screensaver", "lock"]):
        if have(args[0]):
            run(args, check=False)
            return
    raise ShortcutError("couldn't find a way to lock the screen")


def open_target(target: str) -> None:
    if not have("xdg-open"):
        raise ShortcutError("install xdg-utils")
    detach(["xdg-open", target])


def open_app(name: str) -> None:
    import shlex
    name = name.strip()
    desktop_id = name if name.endswith(".desktop") else f"{name}.desktop"
    dirs = [Path.home() / ".local/share/applications", Path("/usr/share/applications"),
            Path("/var/lib/flatpak/exports/share/applications"),
            Path.home() / ".local/share/flatpak/exports/share/applications"]
    if have("gtk-launch") and any((d / desktop_id).exists() for d in dirs):
        detach(["gtk-launch", desktop_id])
    else:
        detach(shlex.split(name))


# ── doctor ─────────────────────────────────────────────────────────────────

FEATURES = {
    "dialogs": ["zenity", "kdialog", "yad"],
    "notifications": ["notify-send"],
    "clipboard": ["wl-copy", "xclip", "xsel"],
    "typing / keys": ["xdotool", "wtype", "ydotool"],
    "screenshots": ["grim", "spectacle", "gnome-screenshot", "maim", "scrot"],
    "volume": ["wpctl", "pactl"],
    "brightness": ["brightnessctl"],
    "media": ["playerctl"],
    "open files/urls": ["xdg-open"],
}


def doctor() -> list[tuple[str, list[str], list[str]]]:
    return [(feat, tools, [t for t in tools if have(t)]) for feat, tools in FEATURES.items()]
