"""tuxcut — run and manage shortcuts from the terminal."""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from importlib import resources
from pathlib import Path


from . import __version__, engine, integrations, system
from .engine import ACTIONS, CATEGORIES, SHORTCUT_DIR, ShortcutError

TEMPLATE = """\
name: {name}
description: what this one does
icon: system-run
actions:
  # each step runs in order; its output becomes {{{{result}}}} for the next
  - do: ask_input
    prompt: whats good?
  - do: notify
    title: you said
    body: "{{{{result}}}}"
"""


def _editor() -> str:
    for e in (os.environ.get("VISUAL"), os.environ.get("EDITOR"), "nano", "vim", "vi"):
        if e and shutil.which(e.split()[0]):
            return e
    raise ShortcutError("set $EDITOR so I know what to open")


def cmd_list(a):
    scs = engine.list_shortcuts()
    if not scs:
        print("no shortcuts yet 👀  try `tuxcut init` for some examples or `tuxcut new \"My Shortcut\"`")
        return
    w = max(len(str(s["name"])) for s in scs)
    for s in scs:
        print(f"  {str(s['name']).ljust(w)}  {s.get('description') or ''}")


def cmd_run(a):
    text = a.input
    if text is None and not sys.stdin.isatty():
        text = sys.stdin.read().rstrip("\n")
    sc = engine.find(a.name)
    log = (lambda m: None) if a.quiet else (lambda m: print(m, file=sys.stderr))
    result = engine.run_shortcut(sc, text or "", log=log)
    if result not in (None, ""):
        print(result)


def cmd_new(a):
    SHORTCUT_DIR.mkdir(parents=True, exist_ok=True)
    path = SHORTCUT_DIR / f"{engine.slugify(a.name)}.yaml"
    if path.exists():
        raise ShortcutError(f"'{a.name}' already exists — `tuxcut edit {engine.slugify(a.name)}`")
    path.write_text(TEMPLATE.format(name=a.name))
    print(f"made {path}")
    if not a.no_edit:
        _edit(path)


def _edit(path: Path):
    subprocess.call([*_editor().split(), str(path)])
    try:
        engine.validate(engine.load_file(path).get("actions"))
        print("looks good ✅")
    except ShortcutError as e:
        print(f"⚠ heads up: {e}", file=sys.stderr)


def cmd_edit(a):
    _edit(Path(engine.find(a.name)["_path"]))


def cmd_show(a):
    print(Path(engine.find(a.name)["_path"]).read_text(), end="")


def cmd_delete(a):
    sc = engine.find(a.name)
    if not a.yes and input(f"delete '{sc['name']}'? [y/N] ").strip().lower() not in ("y", "yes"):
        return
    engine.delete(sc)
    launcher = integrations.APPS_DIR / f"tuxcut-{engine.slugify(str(sc['name']))}.desktop"
    launcher.unlink(missing_ok=True)
    print("gone 🫡")


def cmd_actions(a):
    if a.name:
        spec = ACTIONS.get(a.name)
        if not spec:
            raise ShortcutError(f"no action '{a.name}'")
        print(f"{spec.name} — {spec.label} ({spec.category})")
        if spec.help:
            print(f"  {spec.help}")
        for p in spec.params:
            extra = f" [{' | '.join(p.choices)}]" if p.choices else ""
            default = f" (default: {p.default!r})" if p.default not in ("", [], None) else ""
            print(f"  {p.key}: {p.kind}{extra}{default}  — {p.label}")
        print("  save_as: text  — keep the output as a variable")
        return
    for cat in CATEGORIES:
        specs = [s for s in ACTIONS.values() if s.category == cat]
        if specs:
            print(f"\n{cat}")
            for s in specs:
                print(f"  {s.name.ljust(18)} {s.label}")
    print("\n`tuxcut actions <name>` for the details")


def cmd_doctor(a):
    print(f"session: {system.session_type()}   desktop: {system.desktop() or '?'}\n")
    for feat, tools, found in system.doctor():
        mark = "✅" if found else "❌"
        print(f"  {mark} {feat.ljust(16)} {', '.join(found) if found else 'install one of: ' + ', '.join(tools)}")


def cmd_init(a):
    SHORTCUT_DIR.mkdir(parents=True, exist_ok=True)
    added = 0
    for f in resources.files("tuxcuts").joinpath("examples").iterdir():
        if f.name.endswith(".yaml") and not (SHORTCUT_DIR / f.name).exists():
            (SHORTCUT_DIR / f.name).write_text(f.read_text())
            added += 1
    print(f"added {added} example shortcut{'s' if added != 1 else ''} to {SHORTCUT_DIR}")


def cmd_launcher(a):
    print(f"added to your app launcher: {integrations.make_launcher(engine.find(a.name))}")


def cmd_bind(a):
    print(integrations.bind_hotkey(engine.find(a.name), a.keys))


def cmd_gui(a):
    from .gui import main
    main()


def main(argv=None):
    p = argparse.ArgumentParser(prog="tuxcut", description="Apple Shortcuts vibes for Linux 🐧")
    p.add_argument("--version", action="version", version=f"tuxcuts {__version__}")
    sub = p.add_subparsers(dest="cmd", metavar="command")

    sub.add_parser("list", help="list your shortcuts").set_defaults(fn=cmd_list)
    r = sub.add_parser("run", help="run a shortcut (piped stdin becomes its input)")
    r.add_argument("name")
    r.add_argument("-i", "--input", help="input text")
    r.add_argument("-q", "--quiet", action="store_true", help="don't print each step")
    r.set_defaults(fn=cmd_run)
    n = sub.add_parser("new", help="make a new shortcut")
    n.add_argument("name")
    n.add_argument("--no-edit", action="store_true")
    n.set_defaults(fn=cmd_new)
    for name, fn, h in (("edit", cmd_edit, "open a shortcut in $EDITOR"),
                        ("show", cmd_show, "print a shortcut's YAML"),
                        ("launcher", cmd_launcher, "add a shortcut to your app menu")):
        s = sub.add_parser(name, help=h)
        s.add_argument("name")
        s.set_defaults(fn=fn)
    d = sub.add_parser("delete", help="delete a shortcut")
    d.add_argument("name")
    d.add_argument("-y", "--yes", action="store_true")
    d.set_defaults(fn=cmd_delete)
    b = sub.add_parser("bind", help="give a shortcut a global hotkey, e.g. super+shift+n")
    b.add_argument("name")
    b.add_argument("keys")
    b.set_defaults(fn=cmd_bind)
    ac = sub.add_parser("actions", help="list every action (or details for one)")
    ac.add_argument("name", nargs="?")
    ac.set_defaults(fn=cmd_actions)
    sub.add_parser("doctor", help="check which helper tools you have").set_defaults(fn=cmd_doctor)
    sub.add_parser("init", help="add the example shortcuts").set_defaults(fn=cmd_init)
    sub.add_parser("gui", help="open the editor app").set_defaults(fn=cmd_gui)

    a = p.parse_args(argv)
    if not a.cmd:
        p.print_help()
        return 0
    try:
        a.fn(a)
    except ShortcutError as e:
        print(f"tuxcut: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
