"""Hooks a shortcut into the desktop: app-launcher entries and global hotkeys."""
from __future__ import annotations

import ast
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from .engine import slugify
from .system import ShortcutError, desktop, is_gnome, is_kde

APPS_DIR = Path.home() / ".local/share/applications"


def run_command(sc: dict) -> str:
    exe = shutil.which("tuxcut")
    for cand in (Path.home() / ".local/bin/tuxcut", Path(sys.executable).parent / "tuxcut"):
        if not exe and cand.exists():
            exe = str(cand)
    base = shlex.quote(exe) if exe else f"{shlex.quote(sys.executable)} -m tuxcuts"
    return f"{base} run {slugify(str(sc['name']))}"


def make_launcher(sc: dict) -> Path:
    """Adds the shortcut to the app menu / launcher (and GNOME/KDE search)."""
    APPS_DIR.mkdir(parents=True, exist_ok=True)
    path = APPS_DIR / f"tuxcut-{slugify(str(sc['name']))}.desktop"
    path.write_text(
        "[Desktop Entry]\nType=Application\n"
        f"Name={sc['name']}\n"
        f"Comment={sc.get('description') or 'Tuxcuts shortcut'}\n"
        f"Exec={run_command(sc)}\n"
        f"Icon={sc.get('icon') or 'system-run'}\n"
        "Terminal=false\nCategories=Utility;\nKeywords=shortcut;tuxcut;\n"
    )
    if shutil.which("update-desktop-database"):
        subprocess.run(["update-desktop-database", str(APPS_DIR)], capture_output=True)
    return path


def _split(keys: str):
    parts = [p.strip().lower() for p in keys.replace(" ", "").split("+") if p]
    if len(parts) < 1:
        raise ShortcutError("give keys like super+shift+n")
    alias = {"control": "ctrl", "win": "super", "meta": "super", "mod": "super", "cmd": "super"}
    return [alias.get(p, p) for p in parts[:-1]], parts[-1]


def _gnome_bind(sc: dict, keys: str) -> str:
    mods, key = _split(keys)
    tag = {"ctrl": "<Control>", "shift": "<Shift>", "alt": "<Alt>", "super": "<Super>"}
    binding = "".join(tag.get(m, f"<{m.title()}>") for m in mods) + key
    schema = "org.gnome.settings-daemon.plugins.media-keys"
    cur = subprocess.run(["gsettings", "get", schema, "custom-keybindings"],
                         capture_output=True, text=True).stdout.strip()
    try:
        paths = ast.literal_eval(cur.replace("@as", "").strip() or "[]")
    except (ValueError, SyntaxError):
        paths = []
    slug = slugify(str(sc["name"])).replace("-", "_")
    path = f"/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/tuxcut_{slug}/"
    if path not in paths:
        paths.append(path)
        subprocess.run(["gsettings", "set", schema, "custom-keybindings", str(paths)], check=True)
    sub = f"{schema}.custom-keybinding:{path}"
    for k, v in (("name", f"Tuxcut: {sc['name']}"), ("command", run_command(sc)), ("binding", binding)):
        subprocess.run(["gsettings", "set", sub, k, v], check=True)
    return f"bound {binding} → {sc['name']} ✅"


def bind_hotkey(sc: dict, keys: str) -> str:
    """Binds automatically on GNOME; prints the exact line to paste elsewhere."""
    cmd = run_command(sc)
    d = desktop()
    mods, key = _split(keys)
    if (is_gnome() or "unity" in d or "budgie" in d) and shutil.which("gsettings"):
        return _gnome_bind(sc, keys)
    if "hyprland" in d:
        hm = " ".join(m.upper() for m in mods)
        return f"add this to ~/.config/hypr/hyprland.conf:\n\n  bind = {hm}, {key}, exec, {cmd}"
    if "sway" in d:
        sm = {"super": "Mod4", "alt": "Mod1", "ctrl": "Ctrl", "shift": "Shift"}
        combo = "+".join([sm.get(m, m) for m in mods] + [key])
        return f"add this to ~/.config/sway/config:\n\n  bindsym {combo} exec {cmd}"
    if "niri" in d:
        nm = {"super": "Mod", "alt": "Alt", "ctrl": "Ctrl", "shift": "Shift"}
        combo = "+".join([nm.get(m, m.title()) for m in mods] + [key.upper() if len(key) == 1 else key])
        return f'add this to the binds {{}} block in ~/.config/niri/config.kdl:\n\n  {combo} {{ spawn "sh" "-c" "{cmd}"; }}'
    if is_kde():
        return ("KDE: System Settings → Keyboard → Shortcuts → Add New → Command or Script\n"
                f"  command: {cmd}\n  then set the key to {keys}\n"
                "(or run `tuxcut launcher` first and bind the app entry directly)")
    if "xfce" in d and shutil.which("xfconf-query"):
        xm = {"super": "<Super>", "alt": "<Alt>", "ctrl": "<Primary>", "shift": "<Shift>"}
        combo = "".join(xm.get(m, "") for m in mods) + key
        subprocess.run(["xfconf-query", "-c", "xfce4-keyboard-shortcuts", "-p",
                        f"/commands/custom/{combo}", "-n", "-t", "string", "-s", cmd], check=True)
        return f"bound {combo} → {sc['name']} ✅"
    return f"couldn't auto-bind on this desktop — point your hotkey settings at:\n\n  {cmd}"
