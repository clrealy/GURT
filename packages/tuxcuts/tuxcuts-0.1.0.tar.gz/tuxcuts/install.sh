#!/usr/bin/env bash
# Installs Tuxcuts for your user: ~/.local/share/tuxcuts (venv) + ~/.local/bin/{tuxcut,tuxcuts}
set -euo pipefail
cd "$(dirname "$0")"

say() { printf '\033[1;35m▸\033[0m %s\n' "$*"; }

# the GUI uses your distro's GTK bindings, so the venv sees system packages
if ! python3 -c 'import gi; gi.require_version("Gtk","3.0")' 2>/dev/null; then
  say "GTK bindings missing — the CLI will work, the GUI won't until you install:"
  if   command -v apt    >/dev/null; then echo "    sudo apt install python3-gi gir1.2-gtk-3.0"
  elif command -v dnf    >/dev/null; then echo "    sudo dnf install python3-gobject gtk3"
  elif command -v pacman >/dev/null; then echo "    sudo pacman -S python-gobject gtk3"
  elif command -v zypper >/dev/null; then echo "    sudo zypper install python3-gobject-Gdk typelib-1_0-Gtk-3_0"
  else echo "    PyGObject + GTK 3 from your package manager"; fi
fi

VENV="$HOME/.local/share/tuxcuts/venv"
say "making venv at $VENV"
python3 -m venv --system-site-packages "$VENV"
"$VENV/bin/pip" install --quiet --upgrade .

mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
ln -sf "$VENV/bin/tuxcut"  "$HOME/.local/bin/tuxcut"
ln -sf "$VENV/bin/tuxcuts" "$HOME/.local/bin/tuxcuts"
sed "s|^Exec=.*|Exec=$HOME/.local/bin/tuxcuts|" tuxcuts.desktop > "$HOME/.local/share/applications/tuxcuts.desktop"

"$HOME/.local/bin/tuxcut" init
say "done 🐧  run \`tuxcut doctor\` to see which helper tools you're missing"
case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) say "add ~/.local/bin to your PATH";; esac
